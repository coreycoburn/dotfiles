#parse("Laravel Ideal Header.php")

#parse("Laravel Ideal Class Name.php")
{
    $END$
}